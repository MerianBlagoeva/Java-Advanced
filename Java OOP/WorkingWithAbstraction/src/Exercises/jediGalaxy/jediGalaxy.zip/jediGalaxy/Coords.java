package workingWithAbstraction.jediGalaxy;

public class Coords {
    public int row;
    public int col;

    public Coords(int row, int col) {
        this.row = row;
        this.col = col;
    }
}
